from django.urls import path

#import os
#import sys

#father_path = os.path.abspath(os.path.join(os.getcwd(), "..", "book001"))
#sys.path.append(father_path)
from book001 import views

urlpatterns = [
    path('book001/add/', views.book_create, name='book_create'),
    path('book001/<int:book_id>/update/', views.book_update, name='book_update'),
    path('book001/<int:book_id>/delete/', views.book_delete, name='book_delete'),
    path('book001/<int:book_id>/', views.book_detail, name='book_detail'),
    path('book001/', views.book_list, name='book_list'),

]