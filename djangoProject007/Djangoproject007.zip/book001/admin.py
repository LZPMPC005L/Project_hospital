from django.contrib import admin

# Register your models here.
from book001 import models
admin.site.register(models.Book)